package jp.co.f1.superintro.ch8;

public class HighAndLowS01 {

	public static void main(String[] args) {
		System.out.println("※※※※※※※※※※※※");
		System.out.println("※  High & Low  ※");
		System.out.println("※※※※※※※※※※※※");
		System.out.println("");
		System.out.println("--ゲーム終了--");

	}

}
