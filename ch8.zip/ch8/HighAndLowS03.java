package jp.co.f1.superintro.ch8;

public class HighAndLowS03 {

	public static void main(String[] args) {
		int leftCard = (int)(Math.random()*9)+1;
		System.out.println("************************");
		System.out.println("*  High & Low  *");
		System.out.println("************************");
		System.out.println("");
		System.out.println("  [問題表示]");
		System.out.println(" ***** 	***** ");
		System.out.println(" *   *	* * * ");
		System.out.println(" * "+leftCard+" *	* * * ");
		System.out.println(" *   *	* * * ");
		System.out.println(" ***** 	***** ");
		System.out.println("");
		System.out.println("--ゲーム終了--");

	}

}
